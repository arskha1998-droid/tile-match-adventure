# Tile Match Adventure Android

Android WebView wrapper around the supplied Tile Match Adventure HTML game.

Build outputs:
- APK: `app/build/outputs/apk/release/app-release.apk`
- AAB: `app/build/outputs/bundle/release/app-release.aab`

The release build is signed with the standard debug key for testing. For Google Play publishing, replace it with a private release/upload keystore.
