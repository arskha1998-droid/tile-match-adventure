package com.tilematch.adventure

import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.ads.AdLoader
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.nativead.NativeAd
import com.google.android.gms.ads.nativead.NativeAdOptions
import com.google.android.gms.ads.nativead.NativeAdView
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback

class MainActivity : AppCompatActivity() {
    private var interstitial: InterstitialAd? = null
    private var nativeAd: NativeAd? = null

    private val interstitialId = "ca-app-pub-5452752382144758/7683736206"
    private val nativeId = "ca-app-pub-5452752382144758/9635996608"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val web = findViewById<WebView>(R.id.gameWebView)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.mediaPlaybackRequiresUserGesture = false
        web.webViewClient = WebViewClient()
        web.webChromeClient = WebChromeClient()
        web.addJavascriptInterface(GameBridge(), "Android")
        web.loadUrl("file:///android_asset/game.html")

        MobileAds.initialize(this) {}
        findViewById<com.google.android.gms.ads.AdView>(R.id.bannerAd)
            .loadAd(AdRequest.Builder().build())

        loadInterstitial()
        loadNativeAd()
    }

    private fun loadInterstitial() {
        InterstitialAd.load(
            this,
            interstitialId,
            AdRequest.Builder().build(),
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: InterstitialAd) {
                    interstitial = ad
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    interstitial = null
                }
            }
        )
    }

    private fun showInterstitial() {
        val ad = interstitial
        if (ad != null) {
            ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                override fun onAdDismissedFullScreenContent() {
                    interstitial = null
                    loadInterstitial()
                }
            }
            ad.show(this)
        } else {
            loadInterstitial()
        }
    }

    private fun loadNativeAd() {
        val container = findViewById<FrameLayout>(R.id.nativeAdContainer)
        val adLoader = AdLoader.Builder(this, nativeId)
            .forNativeAd { ad ->
                nativeAd?.destroy()
                nativeAd = ad

                val adView = layoutInflater.inflate(
                    R.layout.native_ad,
                    container,
                    false
                ) as NativeAdView

                adView.headlineView = adView.findViewById(R.id.nativeHeadline)
                adView.bodyView = adView.findViewById(R.id.nativeBody)
                adView.callToActionView = adView.findViewById(R.id.nativeCta)

                (adView.headlineView as TextView).text = ad.headline

                if (ad.body == null) {
                    adView.bodyView?.visibility = android.view.View.GONE
                } else {
                    adView.bodyView?.visibility = android.view.View.VISIBLE
                    (adView.bodyView as TextView).text = ad.body
                }

                if (ad.callToAction == null) {
                    adView.callToActionView?.visibility = android.view.View.GONE
                } else {
                    adView.callToActionView?.visibility = android.view.View.VISIBLE
                    (adView.callToActionView as TextView).text = ad.callToAction
                }

                adView.setNativeAd(ad)
                container.removeAllViews()
                container.addView(adView)
                container.visibility = android.view.View.VISIBLE
            }
            .withNativeAdOptions(NativeAdOptions.Builder().build())
            .build()

        adLoader.loadAd(AdRequest.Builder().build())
    }

    inner class GameBridge {
        @JavascriptInterface
        fun levelCompleted() {
            runOnUiThread { showInterstitial() }
        }
    }

    override fun onDestroy() {
        nativeAd?.destroy()
        findViewById<WebView>(R.id.gameWebView)?.destroy()
        super.onDestroy()
    }
}
