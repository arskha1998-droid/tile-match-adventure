# Tile Match Adventure — Android

Package: `com.tilematch.adventure`

## AdMob configuration
- App ID: `ca-app-pub-5452752382144758~4766721415`
- Banner: `ca-app-pub-5452752382144758/5262329259`
- Interstitial: `ca-app-pub-5452752382144758/7683736206`
- Native: `ca-app-pub-5452752382144758/9635996608`

The Android app integrates the Banner, Interstitial, and Native ad units. Interstitial ads are requested at the level-completion natural break. The Native ad is displayed in the native ad container when an ad is successfully loaded.

For production release, complete AdMob account/app setup, privacy disclosures, consent requirements where applicable, and Play Console release/signing requirements. Do not click production ads while testing.
